import {
    Column,
    Entity,
    PrimaryGeneratedColumn,
    Unique,
} from 'typeorm';

/**
 * To create user table in database
 */
@Entity()
@Unique(['emailId'])
export class User {

    /**
     * To generate id column
     */
    @PrimaryGeneratedColumn()
    id: number;

    /**
     *  To generate userName column
     */
    @Column()
    userName: string;

    /**
     *  To generate emailId column
     */
    @Column()
    emailId: string;

    /**
     *  To generate password column
     */
    @Column()
    password: string;

    /**
     *  To generate id phonenumber column
     */
    @Column()
    phoneNumber: string;

    /*
    @Column({ type: 'enum', enum: Role, default: Role.User })
    role: Role;*/
}
