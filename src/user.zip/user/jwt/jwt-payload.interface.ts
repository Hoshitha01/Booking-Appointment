/**
 * To declare our 
 */
 export interface JwtPayload {
    emailId: string;
  }
  